
window.addEventListener('DOMContentLoaded', function () {
    showSliderImg(sliderImg);
    showTasteImg(tasteImg)
})



let tasteImg = [
    {
        src: './imgs/modaRetro.jpg',
        figcaption: "Moda retro"
    },
    {
        src: './imgs/luna.jpg',
        figcaption: "La luna"
    },
    {
        src: './imgs/abstracto.jpg',
        figcaption: "Lo abstracto"
    },
    {
        src:"./imgs/salsa-teriyaki.jpg",
        figcaption: "Teriyaki"
    },
    {
       src:"./imgs/spaguetti.jpg",
       figcaption:"Spaguetti"
    }
];



let currentTasteIndex = 0;

const tasteImages = document.querySelectorAll(".taste-image")
const TastePrevBtn = document.querySelector(".taste-prev-button");
const TasteNextBtn = document.querySelector(".taste-next-button");
const tasteFigcaption = document.querySelectorAll(".fig");

function showTasteImg(imgs) {
    const newArrayOfImages = [...imgs];

    tasteImages.forEach(function (image, index) {
        const setsrc = newArrayOfImages[index];
        image.setAttribute('src', setsrc.src);
    })

    tasteFigcaption.forEach(function (figcaption, index) {
        const setFigcaption = newArrayOfImages[index];
        figcaption.textContent = setFigcaption.figcaption;
    })
}

TasteNextBtn.addEventListener('click', function () {
    tasteImg = rearrangeArrayForward(tasteImg);
    currentTasteIndex = (currentTasteIndex + 1) % tasteImg.length;
    showTasteImg(tasteImg);
});

TastePrevBtn.addEventListener('click', function () {
    tasteImg = rearrangeArrayBackward(tasteImg);
    currentTasteIndex = (currentTasteIndex - 1 + tasteImg.length) % tasteImg.length;
    showTasteImg(tasteImg);
});



let sliderImg = [
    {
        id: 1,
        src: './imgs/libros.jpg',
        h2: "Libros",
        paragraph: `La magia de los libros es que nos dan experiencia, conocimiento y nos
        entran a un hermoso mundo lleno de explendor, ficcion, amor y dolor, son capaces de mostrarnos
        los sentimientos de aquellos que protagonizan la historia, o mostrarnos una manera revolucionaria de ver la vida.
        Los libros son algo que debemos apreciar con todo el corazón y algo con lo que debemos maravillarnos. Me alegro que te
        gusten los libros, me alegro que seas feliz con ellos.`
    },
    {
        id: 2,
        src: './imgs/documentales.jpg',
        h2: "Documentales",
        paragraph: `Los documentales son un gran aporte de conocimiento y nos muestran la realidad y el funcionamiento de las cosas,
        todos quisieramos estar en muchos documentales de asesinatos... pero vivos jajaja. Entiendo todos tus gustos sobre los documentales
        porque la verdad es algo que te entra tanto y tanto que aveces nos hace dificil salir.`
    },
    {
        id: 3,
        src: './imgs/astrologia.jpg',
        h2: "Astrologia",
        paragraph: `Aunque todavia no soy un fiel seguidor de la astrologia debo decir que uno ha de maravillarse
        por todo lo que existe y ha de admirar las coincidencias y la belleza de las cosas, casualidades que nos traen paz,
        casualidades que nos dan cosas que ni siquiera habriamos pensado que nos harian tan felices. Como tu en la vida de muchas 
        personas, todo lo que te permitió hacer que seas tú hoy en día es algo digno de apreciar.`
    },
    {
        id: 4,
        src: './imgs/fma.jpg',
        h2: "El anime",
        paragraph: `El anime es lo mejor que existe y punto. Aunque tienes muchas fascinaciones con el gore y los animes psicológicos, eso es increible, al igual que en el apartado de la historia, muchas acciones tienen muchos motivos, y lo que te lleva a averiguar el porque y ver la simpleza y belleza de la muert, es algo simplemente inefable`
    },
    {
        id: 5,
        src: "./imgs/abstracto.jpg",
        h2: "Lo abstracto",
        paragraph: `@@@@@@&&%#@---<]`
    },
    {
      id: 6,
      src: "./imgs/terror.jpg",
      h2: "El terror",
      paragraph: `Algo que todo deberiamos sentir en algún momento de nuestras vidas, extrañamente el terror nos dan ganas de vivir y nos muestra que le tememos a los desconocido. Vale totalmente la pena sentirlo, eso nos demuestra que somos humanos.`
    },
    {
      id: 7,
      src: "./imgs/japon-tradicional.jpg",
      h2: "Japón tradicional",
      paragraph: ` En el japón tradicional hay muchas cosas interesantes, pero hablaré sobre su vestimenta. La vestimenta tradicional japonesa destaca por el uso de prendas únicas como el kimono, un vestido largo y colorido usado tanto por hombres, mujeres e infantes, que se ata por la cintura con un cinto de tela(obi) y cuya complejidad ha conducido a su desuso.Existe también un calzado típico de madera(geta) a la manera de zuecos.
      
      La vestimenta contemporánea, en cambio, tiende hacia lo exótico, lo rococó y hacia estilos de diseñador hipercapitalistas, que han convertido a la moda en Japón en una suerte de reflejo extremo de ciertas tendencias occidentales.`
    },
    {
      id: 8,
      src: "./imgs/historia.jpg",
      h2: "La historia",
      paragraph: `Hay cierta admiración en la historia debido a todos los sucesos y acciones que son contadas, la historia en si misma es algo que vale la pena conocer para no repetir las acciones del pasado y para conocer todo los que nos llevó a este futuro. Hay historias de amor, de terror, y de todo tipo, aunque muchas de ellas depende de quien te la cuente, su historia puede ser su verdad pero no la verdad de lo que ocurrió y por eso es fascinante conocer e indagar sobre todo ello. En cuanto a las acciones contadas es dichas historias es algo que vale la pena centrarce, porque muchas veces surgen debido a que creían que hacian lo correcto o por simple orgullo, conocer es la base de un mejor futuro`
    }

];

let currentSliderIndex = 0;

const SliderImages = document.querySelectorAll(".slider-images")
const SliderPrevBtn = document.querySelector(".slider-prev-button");
const sliderNextBtn = document.querySelector(".slider-next-button");
let sliderParagraph = document.getElementById("slider-principal-card-text-paragraph");
let sliderHeader = document.getElementById("slider-principal-card-text-header");



function showSliderImg(imgs) {
    const newArrayOfImages = [...imgs];

    SliderImages.forEach(function (image, index) {
        const setsrc = newArrayOfImages[index];
        image.setAttribute('src', setsrc.src);

    });

    sliderHeader.textContent = sliderImg[0].h2;
    sliderParagraph.textContent = sliderImg[0].paragraph;

}

sliderNextBtn.addEventListener('click', function () {
    sliderImg = rearrangeArrayForward(sliderImg);
    currentSliderIndex = (currentSliderIndex + 1) % sliderImg.length;
    showSliderImg(sliderImg);
});

SliderPrevBtn.addEventListener('click', function () {
    sliderImg = rearrangeArrayBackward(sliderImg);
    currentSliderIndex = (currentSliderIndex - 1 + sliderImg.length) % sliderImg.length;
    showSliderImg(sliderImg);
});



function rearrangeArrayForward(array) {
    const newArray = [...array];
    const lastElement = newArray.pop();
    newArray.unshift(lastElement);
    return newArray;
}

function rearrangeArrayBackward(array) {
    const newArray = [...array];
    const firstElement = newArray.shift();
    newArray.push(firstElement);
    return newArray;
}
